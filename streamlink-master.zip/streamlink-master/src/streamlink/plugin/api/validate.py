# noinspection PyUnresolvedReferences
from streamlink.validate import *  # noqa: F403
