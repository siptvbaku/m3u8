Options
-------

.. module:: streamlink.options

.. autoclass:: Options
    :private-members:

.. autoclass:: Argument

.. autoclass:: Arguments
